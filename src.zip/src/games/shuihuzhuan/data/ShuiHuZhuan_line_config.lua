local ShuiHuZhuan_line_config={
	[1] = {
		['sid'] = 1,
		['locations'] = {2,2,2,2,2},
		['position'] = 372
	},
	[2] = {
		['sid'] = 2,
		['locations'] = {3,3,3,3,3},
		['position'] = 540
	},
	[3] = {
		['sid'] = 3,
		['locations'] = {1,1,1,1,1},
		['position'] = 204
	},
	[4] = {
		['sid'] = 4,
		['locations'] = {3,2,1,2,3},
		['position'] = 364
	},
	[5] = {
		['sid'] = 5,
		['locations'] = {1,2,3,2,1},
		['position'] = 378
	},
	[6] = {
		['sid'] = 6,
		['locations'] = {3,3,2,3,3},
		['position'] = 489
	},
	[7] = {
		['sid'] = 7,
		['locations'] = {1,1,2,1,1},
		['position'] = 253
	},
	[8] = {
		['sid'] = 8,
		['locations'] = {2,1,1,1,2},
		['position'] = 281
	},
	[9] = {
		['sid'] = 9,
		['locations'] = {2,3,3,3,2},
		['position'] = 460
	}
}
return ShuiHuZhuan_line_config