local ShuiGuoLaBa_element_config={
	[1] = {
		['sid'] = 1,
		['tureSid'] = 1
	},
	[2] = {
		['sid'] = 2,
		['tureSid'] = 1
	},
	[3] = {
		['sid'] = 3,
		['tureSid'] = 2
	},
	[4] = {
		['sid'] = 4,
		['tureSid'] = 2
	},
	[5] = {
		['sid'] = 5,
		['tureSid'] = 3
	},
	[6] = {
		['sid'] = 6,
		['tureSid'] = 3
	},
	[7] = {
		['sid'] = 7,
		['tureSid'] = 4
	},
	[8] = {
		['sid'] = 8,
		['tureSid'] = 4
	},
	[9] = {
		['sid'] = 9,
		['tureSid'] = 5
	},
	[10] = {
		['sid'] = 10,
		['tureSid'] = 5
	},
	[11] = {
		['sid'] = 11,
		['tureSid'] = 6
	},
	[12] = {
		['sid'] = 12,
		['tureSid'] = 6
	},
	[13] = {
		['sid'] = 13,
		['tureSid'] = 7
	},
	[14] = {
		['sid'] = 14,
		['tureSid'] = 7
	},
	[15] = {
		['sid'] = 15,
		['tureSid'] = 8
	},
	[16] = {
		['sid'] = 16,
		['tureSid'] = 8
	},
	[17] = {
		['sid'] = 17,
		['tureSid'] = 9
	},
}
return ShuiGuoLaBa_element_config